import json
import re
from pathlib import Path

# ============================================================
# ALWAYS resolve paths relative to THIS script location
# (so it works regardless of where you run python from)
# ============================================================
BASE_DIR = Path(__file__).resolve().parent

INPUT_PATH = BASE_DIR / "data" / "combined" / "combined_dataset_clean.json"
OUTPUT_PATH = BASE_DIR / "data" / "combined" / "combined_dataset_clean_no_milli.json"

print("Running from:", BASE_DIR)
print("Input path:", INPUT_PATH)

# ============================================================
# CHECK INPUT EXISTS
# ============================================================
if not INPUT_PATH.exists():
    raise FileNotFoundError(
        f"\n❌ INPUT FILE NOT FOUND:\n{INPUT_PATH}\n\n"
        f"Put combined_dataset_clean.json inside:\n"
        f"AI-Generated-Text-Detection/data/combined/\n"
    )

# ============================================================
# REGEX: remove ANY word containing 'milli' in any form
# ============================================================
MILLI_PATTERN = re.compile(r'\b\S*milli\S*\b', re.IGNORECASE)

def clean_text(text):
    if not isinstance(text, str):
        return text

    # remove any token containing milli
    text = MILLI_PATTERN.sub('', text)

    # remove extra spaces
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# ============================================================
# LOAD DATA
# ============================================================
with open(INPUT_PATH, "r", encoding="utf-8") as f:
    data = json.load(f)

print(f"Loaded {len(data)} rows")

# ============================================================
# CLEAN
# ============================================================
changed = 0

for item in data:
    original = item.get("content", "")
    cleaned = clean_text(original)

    if cleaned != original:
        changed += 1

    item["content"] = cleaned

print(f"Rows modified: {changed}")

# ============================================================
# SAVE NEW CLEANED JSON
# ============================================================
with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print("\n✅ DONE.")
print("Saved cleaned file to:")
print(OUTPUT_PATH)
print("\nNow use THIS file for model training.")